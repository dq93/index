package shapes;

public class TriangularPrism extends Triangle implements ThreeDObject {
    
    private double height;
    
    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public TriangularPrism(double height, double s1, double s2, double s3) {
        super(s1, s2, s3);
        this.height = height;
    }
    
    @Override
    public double getVolume() {
        return getArea() * height;
    }
    
    @Override
    public double getSurfaceArea() {
        return (2 * getArea()) + (getPerimeter() * height);
    }
    
    public double getLateralArea() {
        return getPerimeter() * height;
    }
}
