package shapes;

public class Cylinder extends Circle implements ThreeDObject{
    private double height;

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public Cylinder(double height, double radius) {
        super(radius);
        this.height = height;
    }
    
    @Override
    public double getVolume() {
        return getArea() * height;
    }
    
    @Override
    public double getSurfaceArea() {
        return (2 * getArea()) + (getPerimeter() * height);
    }
    
    public double getLateralArea() {
        return getPerimeter() * height;
    }
    
}
