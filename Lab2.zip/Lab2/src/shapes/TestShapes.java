/*
Author: Daniel Quintanilla
Date Created: 10/5/23
*/
package shapes;

import javax.swing.JOptionPane;

public class TestShapes {

    public static void main(String[] args) {
        String answer;
        do{
            String choice = JOptionPane.showInputDialog("Which shape would you like to work with?\nPress the number corresponding to each shape:"
                    + "\n1. Circle\n2. Rectangle\n3. Triangle\n4. Cylinder\n5. Rectangular Prism\n6. Triangular Prism\n7. Sphere");

            switch(choice){
                case "1":
                    double radius = Double.parseDouble(JOptionPane.showInputDialog("Enter the radius:"));
                    Circle c1 = new Circle(radius);
                    String output1 = "Area: " + String.format("%.2f", c1.getArea()) + "\n" +  "Perimeter: " + String.format("%.2f", c1.getPerimeter());
                    JOptionPane.showMessageDialog(null, output1);
                    break;
                case "2":
                    double length = Double.parseDouble(JOptionPane.showInputDialog("Enter the length"));
                    double width = Double.parseDouble(JOptionPane.showInputDialog("Enter the width"));
                    Rectangle r1 = new Rectangle(length, width);
                    String output2 = "Area: " + String.format("%.2f", r1.getArea()) + "\n" +  "Perimeter: " + String.format("%.2f", r1.getPerimeter());
                    JOptionPane.showMessageDialog(null, output2);
                    break;
                case "3":
                    double s1 = Double.parseDouble(JOptionPane.showInputDialog("Enter side 1"));
                    double s2 = Double.parseDouble(JOptionPane.showInputDialog("Enter side 2"));
                    double s3 = Double.parseDouble(JOptionPane.showInputDialog("Enter side 3"));
                    Triangle t1 = new Triangle(s1, s2, s3);
                    String output3 = "Semiperimeter: " + String.format("%.2f", t1.getSemiPerimeter()) + "\n" + "Area: "+  String.format("%.2f", t1.getArea())
                        + "\n" + "Perimeter: " + String.format("%.2f", t1.getPerimeter());
                    JOptionPane.showMessageDialog(null, output3);
                    break;
                case "4":
                    double radiusCyl = Double.parseDouble(JOptionPane.showInputDialog("Enter radius"));
                    double heightCyl = Double.parseDouble(JOptionPane.showInputDialog("Enter height"));
                    Cylinder cyl = new Cylinder(heightCyl, radiusCyl);
                    String output4 = "Volume: " + String.format("%.2f", cyl.getVolume()) + "\n" + "Lateral Area: "+  String.format("%.2f", cyl.getLateralArea())
                        + "\n" + "Surface Area: " + String.format("%.2f", cyl.getSurfaceArea());
                    JOptionPane.showMessageDialog(null, output4);
                    break;
                case "5":
                    double rpLength = Double.parseDouble(JOptionPane.showInputDialog("Enter the length"));
                    double rpWidth = Double.parseDouble(JOptionPane.showInputDialog("Enter the width"));
                    double rpHeight = Double.parseDouble(JOptionPane.showInputDialog("Enter the height"));
                    RectangularPrism rp = new RectangularPrism(rpHeight, rpLength, rpWidth);
                    String output5 = "Volume: " + String.format("%.2f", rp.getVolume()) + "\n" + "Lateral Area: "+  String.format("%.2f", rp.getLateralArea())
                        + "\n" + "Surface Area: " + String.format("%.2f", rp.getSurfaceArea());
                    JOptionPane.showMessageDialog(null, output5);
                    break;
                case "6":
                    double tpHeight = Double.parseDouble(JOptionPane.showInputDialog("Enter the height"));
                    double tpS1 = Double.parseDouble(JOptionPane.showInputDialog("Enter side 1"));
                    double tpS2 = Double.parseDouble(JOptionPane.showInputDialog("Enter side 2"));
                    double tpS3 = Double.parseDouble(JOptionPane.showInputDialog("Enter side 3"));
                    TriangularPrism tp1 = new TriangularPrism(tpHeight, tpS1, tpS2, tpS3);
                    String output6 = "Volume: " + String.format("%.2f", tp1.getVolume()) + "\n" + "Lateral Area: "+  String.format("%.2f", tp1.getLateralArea())
                        + "\n" + "Surface Area: " + String.format("%.2f", tp1.getSurfaceArea());
                    JOptionPane.showMessageDialog(null, output6);
                    break;
                case "7":
                    double sphRadius = Double.parseDouble(JOptionPane.showInputDialog("Enter the radius"));
                    Sphere sph1 = new Sphere(sphRadius);
                    String output7 = "Surface Area: " + String.format("%.2f", sph1.getSurfaceArea()) + "\n"
                            + "Volume: " + String.format("%.2f", sph1.getVolume());
                    JOptionPane.showMessageDialog(null, output7);
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Not a valid choice.");
            }
            answer = JOptionPane.showInputDialog("Would you like to repeat this program? Enter y to repeat.");
        }
        while(answer.equalsIgnoreCase("y"));
        
        JOptionPane.showMessageDialog(null, "Bye.");
    }
    
}
