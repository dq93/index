package shapes;

public class RectangularPrism extends Rectangle implements ThreeDObject {
    private double height;

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public RectangularPrism(double height, double length, double width) {
        super(length, width);
        this.height = height;
    }

    @Override
    public double getVolume() {
        return getArea() * height;
    }   

    @Override
    public double getSurfaceArea() {
        return (2 * getArea()) + (getPerimeter() * height);
    }
    
    public double getLateralArea() {
        return getPerimeter() * height;
    }
    
}
