package shapes;

public class Sphere implements ThreeDObject {
    
    private double radius;

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    public Sphere(double radius) {
        this.radius = radius;
    }
    
    @Override
    public double getSurfaceArea() {
        return 4 * Math.PI * radius * radius;
    }
    
    @Override
    public double getVolume() {
        return (4/3) * Math.PI * radius * radius * radius; 
    }
}
