package shapes;

public interface ThreeDObject {
    public double getVolume();
    public double getSurfaceArea();
}
