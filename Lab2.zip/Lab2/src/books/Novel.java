package books;

public class Novel extends Books {
    private String genre;

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public Novel(String genre, Author auth, String title, int pages) {
        super(auth, title, pages);
        this.genre = genre;
    }
    
}
