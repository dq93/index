package books;

public class Books {
    private Author auth;
    private String title;
    private int pages;

    public Author getAuth() {
        return auth;
    }

    public void setAuth(Author auth) {
        this.auth = auth;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getPages() {
        return pages;
    }

    public void setPages(int pages) {
        this.pages = pages;
    }

    public Books(Author auth, String title, int pages) {
        this.auth = auth;
        this.title = title;
        this.pages = pages;
    }
    
}
