/*
Author: Daniel Quintanilla
Date Created: 10/6/23
*/
package books;
import javax.swing.JOptionPane;

public class TestBooks {

    public static void main(String[] args) {
        
        String answer;
        do{
            String name = JOptionPane.showInputDialog("Enter author's name");
            String address = JOptionPane.showInputDialog("Enter author's address");
            String email = JOptionPane.showInputDialog("Enter author's email");
            Author auth1 = new Author(name, address, email);
            
            String choice = JOptionPane.showInputDialog("Is the book a textbook, a novel, or a biography?\n\nEnter 1 for textbook"
                + "\nEnter 2 for novel\nEnter 3 for biography");
            
            switch(choice) {
                case"1":
                    String gradeLevel = JOptionPane.showInputDialog("What is the grade level for this textbook?");
                    String title1 = JOptionPane.showInputDialog("What is the title of this textbook?");
                    int pages1 = Integer.parseInt(JOptionPane.showInputDialog("What is the number of pages of this textbook?"));
                    
                    Textbook t1 = new Textbook(gradeLevel, auth1, title1, pages1);
                    JOptionPane.showMessageDialog(null, "Textbook title: " + t1.getTitle() + "\nGrade level: " + t1.getGradeLevel()
                        + "\nPages: " + t1.getPages());
                    break;
                    
                case"2":
                    String genre = JOptionPane.showInputDialog("What is the genre of this novel?");
                    String title2 = JOptionPane.showInputDialog("What is the title of this novel?");
                    int pages2 = Integer.parseInt(JOptionPane.showInputDialog("What is the number of pages of this novel?"));
                    
                    Novel n1 = new Novel(genre, auth1, title2, pages2);
                    JOptionPane.showMessageDialog(null, "Novel title: " + n1.getTitle() + "\nGenre: " + n1.getGenre()
                        + "\nPages: " + n1.getPages());
                    break;
                    
                case"3":
                    String subject = JOptionPane.showInputDialog("Who is the subject of this biography?");
                    String title3 = JOptionPane.showInputDialog("What is the title of this biography?");
                    int pages3 = Integer.parseInt(JOptionPane.showInputDialog("What is the number of pages of this biography?"));
                    
                    Biography b1 = new Biography(subject, auth1, title3, pages3);
                    JOptionPane.showMessageDialog(null, "Biography title: " + b1.getTitle() + "\nSubject: " + b1.getSubject()
                        + "\nPages: " + b1.getPages());
                    break;
            }
            
            JOptionPane.showMessageDialog(null, "Author name: " + auth1.getName() + "\n" + "Address: " + auth1.getAddress()
                        + "\n" + "Email: " + auth1.getEmail());
            
            answer = JOptionPane.showInputDialog("Would you like to repeat this program? Enter y to repeat.");
        }
        while(answer.equalsIgnoreCase("y"));
        
        JOptionPane.showMessageDialog(null, "Goodbye");
    }
    
}
