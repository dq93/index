package books;

public class Biography extends Books {
    private String subject;

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public Biography(String subject, Author auth, String title, int pages) {
        super(auth, title, pages);
        this.subject = subject;
    }
    
}
