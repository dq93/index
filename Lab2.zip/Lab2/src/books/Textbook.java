package books;

public class Textbook extends Books {
    private String gradeLevel;

    public String getGradeLevel() {
        return gradeLevel;
    }

    public void setGradeLevel(String gradeLevel) {
        this.gradeLevel = gradeLevel;
    }

    public Textbook(String gradeLevel, Author auth, String title, int pages) {
        super(auth, title, pages);
        this.gradeLevel = gradeLevel;
    }
    
}
