package colorchooser;

import java.awt.Color;
import java.util.EventObject;

/**
 *
 * @author 00220682
 */
public class ColorEvent extends EventObject {
    private Color color;

    public Color getColor() {
        return color;
    }
    
    public ColorEvent(Object source, Color color){
        super(source);
        this.color = color;
    }

}
