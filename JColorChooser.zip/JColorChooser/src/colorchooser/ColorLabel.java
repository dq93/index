package colorchooser;

import java.awt.Color;
import javax.swing.JLabel;

/**
 *
 * @author 00220682
 */
public class ColorLabel extends JLabel implements ColorListener {

    @Override
    public void changeColor(ColorEvent ce) {
        Color color = ce.getColor();
        setText("Hex: #" + getHexValue(color));
    }

    private String getHexValue(Color color) {
        int red = color.getRed();
        int green = color.getGreen();
        int blue = color.getBlue();
        return String.format("%02X%02X%02X", red, green, blue);
    }

    
    public ColorLabel(){
        super();
        setText("Hex:");
    }
}
