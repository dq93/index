package colorchooser;

import java.awt.Color;

public interface ColorChangeListener {
    void colorChanged(Color newColor);
}
