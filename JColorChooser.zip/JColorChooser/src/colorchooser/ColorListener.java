package colorchooser;

import java.util.EventListener;

/**
 *
 * @author 00220682
 */
public interface ColorListener extends EventListener {
    public void changeColor(ColorEvent ce);
}
